export interface INumberBoxSample {
    name?: string;

    firstNumber?: number;
    secondNumber?: number;
}